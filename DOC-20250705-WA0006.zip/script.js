// script.js

// --- Global Variables for both scenes ---
let animationScene, animationCamera, animationRenderer, animationObject;
let skillScene, skillCamera, skillRenderer, skillControls; // Use OrbitControls for skills
let isAnimationRunning = false; // To control the digital world animation

// --- Digital World Animation Setup ---
const digitalWorldContainer = document.getElementById('digitalWorldAnimationContainer');
const toggleDigitalWorldButton = document.getElementById('toggleDigitalWorldAnimation');

if (digitalWorldContainer && toggleDigitalWorldButton) {
    initDigitalWorldAnimation();
    toggleDigitalWorldButton.addEventListener('click', toggleAnimation);
} else {
    console.error("Digital world animation container or button not found.");
}

function initDigitalWorldAnimation() {
    animationScene = new THREE.Scene();
    animationScene.background = new THREE.Color(0x222222); // Dark background

    animationCamera = new THREE.PerspectiveCamera(75, digitalWorldContainer.clientWidth / digitalWorldContainer.clientHeight, 0.1, 1000);
    animationCamera.position.z = 5;

    animationRenderer = new THREE.WebGLRenderer({ antialias: true });
    animationRenderer.setSize(digitalWorldContainer.clientWidth, digitalWorldContainer.clientHeight);
    digitalWorldContainer.appendChild(animationRenderer.domElement);

    // Add a glowing dodecahedron as the central object
    const geometry = new THREE.DodecahedronGeometry(1.5);
    const material = new THREE.MeshLambertMaterial({ color: 0x00ffff, emissive: 0x00ffff, emissiveIntensity: 0.5 }); // Cyan with glow
    animationObject = new THREE.Mesh(geometry, material);
    animationScene.add(animationObject);

    // Add lights
    const light1 = new THREE.PointLight(0xff00ff, 1, 100); // Magenta light
    light1.position.set(5, 5, 5);
    animationScene.add(light1);

    const light2 = new THREE.PointLight(0x00ff00, 1, 100); // Green light
    light2.position.set(-5, -5, -5);
    animationScene.add(light2);

    const ambient = new THREE.AmbientLight(0x404040); // Soft ambient light
    animationScene.add(ambient);

    window.addEventListener('resize', onDigitalWorldResize, false);
}

function toggleAnimation() {
    if (isAnimationRunning) {
        // Stop animation
        cancelAnimationFrame(animationRequestId); // Assuming animationRequestId is global or passed
        animationRenderer.domElement.style.display = 'none';
        digitalWorldContainer.style.display = 'none'; // Hide container too
        isAnimationRunning = false;
        toggleDigitalWorldButton.textContent = "Show Digital World Fun";
    } else {
        // Start animation
        digitalWorldContainer.style.display = 'block'; // Show container
        animationRenderer.domElement.style.display = 'block';
        animateDigitalWorld();
        isAnimationRunning = true;
        toggleDigitalWorldButton.textContent = "Hide Digital World Fun";
    }
}

let animationRequestId;
function animateDigitalWorld() {
    animationRequestId = requestAnimationFrame(animateDigitalWorld);

    if (animationObject) {
        animationObject.rotation.x += 0.005;
        animationObject.rotation.y += 0.008;
    }

    animationRenderer.render(animationScene, animationCamera);
}

function onDigitalWorldResize() {
    animationCamera.aspect = digitalWorldContainer.clientWidth / digitalWorldContainer.clientHeight;
    animationCamera.updateProjectionMatrix();
    animationRenderer.setSize(digitalWorldContainer.clientWidth, digitalWorldContainer.clientHeight);
}


// --- Skill Development Visualization Setup ---
const skillsData = [
    { name: "Web Dev", value: 80, color: 0x4a90e2 }, // Blue
    { name: "Networking", value: 60, color: 0x7ed321 }, // Green
    { name: "Programming", value: 70, color: 0xf5a623 }, // Orange
    { name: "Databases", value: 45, color: 0xbd10e0 }, // Purple
    { name: "Linux", value: 55, color: 0x50e3c2 }  // Teal
];

const skillVizContainer = document.getElementById('skillVisualization3D');

if (skillVizContainer) {
    initSkillVisualization();
    animateSkillVisualization();
} else {
    console.error("Skill visualization container not found: #skillVisualization3D");
}

function initSkillVisualization() {
    // 1. Scene
    skillScene = new THREE.Scene();
    skillScene.background = new THREE.Color(0xf0f8ff); // Alice Blue background

    // 2. Camera
    const aspect = skillVizContainer.clientWidth / skillVizContainer.clientHeight;
    skillCamera = new THREE.PerspectiveCamera(75, aspect, 0.1, 1000);
    skillCamera.position.set(0, 50, 120); // Position to view all bars

    // 3. Renderer
    skillRenderer = new THREE.WebGLRenderer({ antialias: true });
    skillRenderer.setSize(skillVizContainer.clientWidth, skillVizContainer.clientHeight);
    skillVizContainer.appendChild(skillRenderer.domElement);

    // 4. Lights
    const ambientLight = new THREE.AmbientLight(0x404040, 2); // Soft white light
    skillScene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(0, 100, 50).normalize();
    skillScene.add(directionalLight);

    // 5. Create 3D Bars
    const barWidth = 15;
    const barDepth = 15;
    const spacing = 25; // Increased space between bars
    const startX = -(skillsData.length - 1) * spacing / 2; // Center the bars

    skillsData.forEach((skill, index) => {
        const barHeight = skill.value; // Use skill value directly as height
        const geometry = new THREE.BoxGeometry(barWidth, barHeight, barDepth);
        const material = new THREE.MeshStandardMaterial({
            color: skill.color,
            roughness: 0.5, // Slightly reflective
            metalness: 0.2 // A bit metallic look
        });
        const bar = new THREE.Mesh(geometry, material);

        // Position the bar
        bar.position.x = startX + index * spacing;
        bar.position.y = barHeight / 2; // Half height to rest on ground
        bar.position.z = 0;

        // Add a subtle name property for potential future raycasting/hover effects
        bar.userData = { name: skill.name, value: skill.value };

        skillScene.add(bar);
    });

    // Add a base plane
    const planeGeometry = new THREE.PlaneGeometry(barWidth * skillsData.length * 2, barDepth * 3); // Larger plane
    const planeMaterial = new THREE.MeshStandardMaterial({ color: 0xadd8e6, roughness: 0.8, metalness: 0.1, side: THREE.DoubleSide }); // Light blue, less reflective
    const plane = new THREE.Mesh(planeGeometry, planeMaterial);
    plane.rotation.x = -Math.PI / 2; // Rotate to be horizontal
    plane.position.y = -0.1; // Slightly below bars
    skillScene.add(plane);


    // 6. OrbitControls for interaction
    skillControls = new THREE.OrbitControls(skillCamera, skillRenderer.domElement);
    skillControls.enableDamping = true; // Smooth camera movements
    skillControls.dampingFactor = 0.25;
    skillControls.screenSpacePanning = false;
    skillControls.maxPolarAngle = Math.PI / 2; // Prevent camera from going below the ground

    // Handle window resizing
    window.addEventListener('resize', onSkillVizResize, false);
}

function onSkillVizResize() {
    skillCamera.aspect = skillVizContainer.clientWidth / skillVizContainer.clientHeight;
    skillCamera.updateProjectionMatrix();
    skillRenderer.setSize(skillVizContainer.clientWidth, skillVizContainer.clientHeight);
}

function animateSkillVisualization() {
    requestAnimationFrame(animateSkillVisualization);

    skillControls.update(); // Only required if controls.enableDamping or controls.autoRotate are set to true

    skillRenderer.render(skillScene, skillCamera);
}

// --- General Resizing Listener (if needed for other elements) ---
// window.addEventListener('resize', () => {
//     // Any other elements that need resizing logic
// });